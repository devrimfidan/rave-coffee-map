#!/bin/bash
# Run this once inside the rave-coffee-map folder to initialise git

cd "$(dirname "$0")"

git init
git add .
git commit -m "feat: initial Rave Coffee world map

- Interactive world map with 32 coffee pins
- Rave-styled flip cards (front: roast/flavours, back: origin/process/notes)
- Region filter (Africa, Americas, Asia, Blends)
- Pan, zoom, touch support
- No build step — pure HTML/JS"

echo ""
echo "✅ Git repo initialised."
echo ""
echo "Next steps:"
echo "  1. Create a new repo on GitHub (https://github.com/new)"
echo "  2. Run:"
echo "     git remote add origin https://github.com/YOUR_USERNAME/rave-coffee-map.git"
echo "     git branch -M main"
echo "     git push -u origin main"
echo "  3. Enable GitHub Pages: Settings → Pages → Source: main / root"
echo ""
